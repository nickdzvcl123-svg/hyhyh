# GNNKeyGate

iOS SwiftUI key-gate + patch manager template.

## Chức năng
- Màn hình nhập key khi mở app.
- Key admin mặc định: `nickdz123`.
- Admin có thể tạo key ngẫu nhiên và số ngày hiệu lực tùy ý.
- Admin có thể tạo Patch gồm:
  - Tên patch
  - App ID hiển thị để quản lý
  - Đường dẫn file dạng `Documents/tenfile`
  - File patch
- Người dùng chỉ thấy nút toggle theo tên patch.
- Bản an toàn này chỉ áp dụng/khôi phục file trong sandbox của chính app, không can thiệp ứng dụng khác.

## Build
Mở `GNNKeyGate.xcodeproj` bằng Xcode.

GitHub Actions nằm tại `.github/workflows/build.yml`.
Để tạo IPA cài được trên thiết bị thật, GitHub Actions cần chứng thư/provisioning hợp lệ của bạn.
