import Foundation
import SwiftUI

struct AccessKey: Codable, Identifiable {
    let id: UUID
    var value: String
    var expiresAt: Date
    var isAdmin: Bool = false

    var active: Bool {
        isAdmin || expiresAt > Date()
    }
}

struct Patch: Codable, Identifiable {
    let id: UUID
    var name: String
    var appID: String
    var relativePath: String
    var patchFileName: String
    var enabled: Bool = false
}

@MainActor
final class AppStore: ObservableObject {
    @Published var keys: [AccessKey] = []
    @Published var patches: [Patch] = []
    @Published var unlocked = false
    @Published var isAdmin = false

    private let fm = FileManager.default
    private let defaults = UserDefaults.standard

    init() {
        load()
        if !keys.contains(where: { $0.isAdmin && $0.value == "nickdz123" }) {
            keys.append(AccessKey(
                id: UUID(),
                value: "nickdz123",
                expiresAt: Date.distantFuture,
                isAdmin: true
            ))
            save()
        }
    }

    func login(_ value: String) -> Bool {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let key = keys.first(where: { $0.value == trimmed && $0.active }) else {
            return false
        }
        unlocked = true
        isAdmin = key.isAdmin
        return true
    }

    func logout() {
        unlocked = false
        isAdmin = false
    }

    func createKey(days: Int) -> String {
        let value = "FREE-" + UUID().uuidString
            .replacingOccurrences(of: "-", with: "")
            .prefix(12)
        keys.append(AccessKey(
            id: UUID(),
            value: String(value),
            expiresAt: Calendar.current.date(byAdding: .day, value: max(1, days), to: Date())!
        ))
        save()
        return String(value)
    }

    func addPatch(name: String, appID: String, path: String, patchFileName: String) {
        patches.append(Patch(
            id: UUID(),
            name: name,
            appID: appID,
            relativePath: normalized(path),
            patchFileName: patchFileName
        ))
        save()
    }

    func togglePatch(_ patch: Patch, enabled: Bool) {
        guard let index = patches.firstIndex(where: { $0.id == patch.id }) else { return }

        let patchDir = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let target = patchDir.appendingPathComponent(normalized(patch.relativePath))

        do {
            if enabled {
                // Safe behavior: target is inside this app's Documents directory.
                let backup = target.appendingPathExtension("gnn-original")
                if fm.fileExists(atPath: target.path), !fm.fileExists(atPath: backup.path) {
                    try fm.copyItem(at: target, to: backup)
                }

                let source = patchDir.appendingPathComponent(patch.patchFileName)
                if fm.fileExists(atPath: source.path) {
                    if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
                    try fm.copyItem(at: source, to: target)
                }
            } else {
                let backup = target.appendingPathExtension("gnn-original")
                if fm.fileExists(atPath: backup.path) {
                    if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
                    try fm.moveItem(at: backup, to: target)
                }
            }

            patches[index].enabled = enabled
            save()
        } catch {
            patches[index].enabled = false
            save()
        }
    }

    private func normalized(_ path: String) -> String {
        var p = path.replacingOccurrences(of: "\\", with: "/")
        if p.hasPrefix("/") { p.removeFirst() }
        if p.hasPrefix("Documents/") {
            p = String(p.dropFirst("Documents/".count))
        }
        // Prevent path traversal.
        p = p.split(separator: "/").filter { $0 != ".." && $0 != "." }.joined(separator: "/")
        return p
    }

    private var storeURL: URL {
        fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("gnn-store.json")
    }

    private func save() {
        do {
            let dir = storeURL.deletingLastPathComponent()
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(StoreData(keys: keys, patches: patches))
            try data.write(to: storeURL, options: .atomic)
        } catch {}
    }

    private func load() {
        guard let data = try? Data(contentsOf: storeURL),
              let value = try? JSONDecoder().decode(StoreData.self, from: data) else { return }
        keys = value.keys
        patches = value.patches
    }
}

private struct StoreData: Codable {
    var keys: [AccessKey]
    var patches: [Patch]
}
