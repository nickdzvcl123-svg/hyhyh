import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.black, Color.blue.opacity(0.35), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()

            if !store.unlocked {
                LoginView()
            } else {
                NavigationStack {
                    if store.isAdmin {
                        AdminView()
                    } else {
                        UserView()
                    }
                }
                .preferredColorScheme(.dark)
            }
        }
    }
}

struct LoginView: View {
    @EnvironmentObject var store: AppStore
    @State private var key = ""
    @State private var error = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("GNN KEY GATE")
                .font(.system(size: 34, weight: .black))
            Text("Nhập key để tiếp tục")
                .foregroundStyle(.secondary)

            SecureField("KEY", text: $key)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

            Button("KÍCH HOẠT") {
                if !store.login(key) {
                    error = "Key không hợp lệ hoặc đã hết hạn."
                }
            }
            .buttonStyle(.borderedProminent)

            if !error.isEmpty {
                Text(error).foregroundStyle(.red)
            }
        }
        .padding(28)
        .foregroundStyle(.white)
    }
}

struct UserView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        List {
            Section("PATCH") {
                if store.patches.isEmpty {
                    Text("Chưa có patch.")
                }

                ForEach(store.patches) { patch in
                    Toggle(patch.name, isOn: Binding(
                        get: { patch.enabled },
                        set: { store.togglePatch(patch, enabled: $0) }
                    ))
                    VStack(alignment: .leading, spacing: 3) {
                        Text(patch.appID)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("Documents/" + patch.relativePath)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Button("Đăng xuất") { store.logout() }
        }
        .navigationTitle("GNN PATCH")
    }
}

struct AdminView: View {
    @EnvironmentObject var store: AppStore
    @State private var days = "30"
    @State private var generated = ""

    @State private var patchName = ""
    @State private var appID = ""
    @State private var path = ""
    @State private var patchFile = ""

    var body: some View {
        Form {
            Section("ADMIN") {
                Text("Admin key: nickdz123")
                HStack {
                    TextField("Số ngày", text: $days)
                        .keyboardType(.numberPad)
                    Button("TẠO KEY") {
                        generated = store.createKey(days: Int(days) ?? 30)
                    }
                }
                if !generated.isEmpty {
                    Text("Key mới: \(generated)")
                        .textSelection(.enabled)
                }
            }

            Section("THÊM PATCH") {
                TextField("Tên patch", text: $patchName)
                TextField("App ID", text: $appID)
                    .textInputAutocapitalization(.never)
                TextField("Đường dẫn, ví dụ Documents/config.dat", text: $path)
                    .textInputAutocapitalization(.never)
                TextField("Tên file patch trong Documents", text: $patchFile)

                Button("THÊM PATCH") {
                    guard !patchName.isEmpty, !appID.isEmpty,
                          !path.isEmpty, !patchFile.isEmpty else { return }
                    store.addPatch(
                        name: patchName,
                        appID: appID,
                        path: path,
                        patchFileName: patchFile
                    )
                    patchName = ""
                    appID = ""
                    path = ""
                    patchFile = ""
                }
            }

            Section("PATCH ĐÃ TẠO") {
                ForEach(store.patches) { p in
                    VStack(alignment: .leading) {
                        Text(p.name).font(.headline)
                        Text(p.appID).font(.caption)
                        Text("Documents/" + p.relativePath).font(.caption2)
                    }
                }
            }

            Button("Đăng xuất") { store.logout() }
        }
        .navigationTitle("ADMIN PANEL")
    }
}
